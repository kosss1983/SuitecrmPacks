<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.13.2';
$suitecrm_timestamp = '2023-03-02 12:00:00';
